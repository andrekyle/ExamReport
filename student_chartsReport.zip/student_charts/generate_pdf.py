import pdfkit
import os

# Configuration for wkhtmltopdf
config = pdfkit.configuration(wkhtmltopdf='C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe')

# Options for PDF generation
options = {
    'page-size': 'A4',
    'margin-top': '0.75in',
    'margin-right': '0.75in',
    'margin-bottom': '0.75in',
    'margin-left': '0.75in',
    'encoding': 'UTF-8',
    'no-outline': None,
    'enable-local-file-access': None
}

# Generate PDF from the HTML file
try:
    pdfkit.from_file('index.html', 'exam_results_report.pdf', options=options, configuration=config)
    print("PDF generated successfully as 'exam_results_report.pdf'")
except Exception as e:
    print(f"Error generating PDF: {str(e)}")
    print("Please make sure wkhtmltopdf is installed on your system.")
