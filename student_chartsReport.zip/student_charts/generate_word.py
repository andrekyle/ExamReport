from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE

def create_word_report():
    doc = Document()
    
    # Set up styles
    style = doc.styles.add_style('Header Style', WD_STYLE_TYPE.PARAGRAPH)
    style.font.size = Pt(24)
    style.font.color.rgb = RGBColor(26, 35, 126)  # Dark blue color
    
    subtitle_style = doc.styles.add_style('Subtitle Style', WD_STYLE_TYPE.PARAGRAPH)
    subtitle_style.font.size = Pt(16)
    subtitle_style.font.color.rgb = RGBColor(13, 71, 161)  # Lighter blue color
    
    # Title
    title = doc.add_paragraph('Java Oracle Certified Associate Exam Results Report')
    title.style = 'Header Style'
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    subtitle = doc.add_paragraph('Performance Analysis of 28 Students')
    subtitle.style = 'Subtitle Style'
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_paragraph()  # Add spacing
    
    # Introduction
    doc.add_heading('Introduction', level=1)
    intro = doc.add_paragraph()
    intro_text = (
        "This report provides a comprehensive analysis of the performance of 28 students "
        "who took the Java Oracle Certified Associate Exam. The exam requires a minimum "
        "score of 65% to pass. The data includes each student's first name, last name, "
        "and score out of 100. This report presents a statistical summary, key observations, "
        "and visualizations to evaluate the results."
    )
    intro.add_run(intro_text)
    
    # Data Summary
    doc.add_heading('Data Summary', level=1)
    summary = [
        ('Total Students:', '28'),
        ('Passing Score:', '65%'),
        ('Highest Score:', '100% (Oyame Mazaleni)'),
        ('Lowest Score:', '73% (Amogelang Moletsane, Tshepo Basini)'),
        ('Average Score:', '89.71%'),
        ('Median Score:', '91%'),
        ('Standard Deviation:', '7.83')
    ]
    
    for item in summary:
        p = doc.add_paragraph()
        p.add_run(f'{item[0]} ').bold = True
        p.add_run(item[1])
    
    # Visualizations
    doc.add_heading('Visualizations', level=1)
    
    # Add images in a 2x2 grid with captions
    images = [
        ('bar_chart.png', 'Individual Student Scores'),
        ('histogram.png', 'Score Distribution'),
        ('pie_chart.png', 'Score Categories'),
        ('box_plot.png', 'Score Spread')
    ]
    
    for img_path, caption in images:
        doc.add_heading(caption, level=2)
        doc.add_picture(img_path, width=Inches(6))
        doc.add_paragraph()  # Add spacing
    
    # Key Findings
    doc.add_heading('Key Findings', level=1)
    findings = [
        '100% Pass Rate: All 28 students passed the exam, with the lowest score (73) exceeding the 65% threshold by 8 points.',
        'High Achievement: The average score of 89.71 and median of 91 indicate exceptional overall performance.',
        'Score Clustering: 82.1% of students scored 80 or above, with 53.6% in the 90–100 range.',
        'Lower Scores: Five students (17.9%) scored between 73 and 79, still comfortably above the pass mark.'
    ]
    
    for finding in findings:
        doc.add_paragraph(finding, style='List Bullet')
    
    # Recommendations
    doc.add_heading('Recommendations', level=1)
    recommendations = [
        'Celebrate Success: Recognize top performers for their outstanding results.',
        'Support Improvement: Provide feedback or optional resources to students scoring below 80.',
        'Analyze Success Factors: Investigate preparation methods and teaching strategies to replicate this high pass rate.'
    ]
    
    for rec in recommendations:
        doc.add_paragraph(rec, style='List Bullet')
    
    # Footer
    doc.add_paragraph()
    footer = doc.add_paragraph('Report generated on March 25, 2025')
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.style = doc.styles.add_style('Footer Style', WD_STYLE_TYPE.PARAGRAPH)
    footer.style.font.size = Pt(10)
    footer.style.font.color.rgb = RGBColor(108, 117, 125)  # Gray color
    
    # Save the document
    doc.save('exam_results_report.docx')
    print("Word document generated successfully as 'exam_results_report.docx'")

if __name__ == '__main__':
    create_word_report()
